package people

class Patron(
        fName: String,
        lName: String,
        phoneN: String,
        email: String ) : Person(fName = fName, lName = lName, phoneN = phoneN, email = email) {



}